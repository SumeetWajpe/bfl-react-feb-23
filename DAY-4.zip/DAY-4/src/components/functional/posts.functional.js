import React, { useEffect, useState } from "react";
import axios from "axios";

export default function PostsFunctional() {
  let [posts, setPosts] = useState([]);
  useEffect(() => {
    axios
      .get("https://jsonplaceholder.typicode.com/posts")
      .then(response => setPosts(response.data));
  }, []);
  return (
    <div>
      <header>
        <h1>Posts</h1>
      </header>

      <main>
        <ul className="list-group">
          {posts.map(post => (
            <li key={post.id} className="list-group-item">
              {post.title}
            </li>
          ))}
        </ul>
      </main>
    </div>
  );
}
