import { useState } from "react";

export default function Counter() {
  let [data, setData] = useState({ count: 100, age: 30 });

  return (
    <>
      <h3>Count: {data.count}</h3>
      <button onClick={() => setData({ ...data, count: data.count + 1 })}>
        ++{" "}
      </button>
      <hr />
      <h3>Age: {data.age}</h3>
      <button onClick={() => setData({ ...data, age: data.age + 1 })}>
        ++{" "}
      </button>
    </>
  );
}

// import { useState } from "react";

// export default function Counter() {
//   let [count, setCount] = useState(1000);
//   let [age, setAge] = useState(30);

//   return (
//     <>
//       <h3>Count: {count}</h3>
//       <button onClick={() => setCount(count + 1)}>++ </button>
//       <hr />
//       <h3>Age: {age}</h3>
//       <button onClick={() => setAge(age + 1)}>++ </button>
//     </>
//   );
// }
