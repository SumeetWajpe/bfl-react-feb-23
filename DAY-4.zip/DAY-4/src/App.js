import logo from "./logo.svg";
import "./App.css";
import ListOfProducts from "./components/listofproducts/listofproducts";
import React from "react";
import Posts from "./components/posts/posts";
import Message from "./components/functional/message";
import Counter from "./components/functional/counter";
import PostsFunctional from "./components/functional/posts.functional";
import GetPostById from "./components/getpostbyid/getpostbyid";
import { BrowserRouter, Link, Route, Routes } from "react-router-dom";
import NewProduct from "./components/newproduct/newproduct";
class App extends React.Component {
  render() {
    return (
      <BrowserRouter>
        <Link to="/">Home</Link> | <Link to="/newproduct">New Product</Link>
        <Routes>
          <Route path="/" element={<ListOfProducts />}></Route>
          <Route path="/newproduct" element={<NewProduct />}></Route>
          <Route path="/posts" element={<Posts />}></Route>
        </Routes>
      </BrowserRouter>
    );
  }
}
export default App;
