import logo from "./logo.svg";
import "./App.css";
import ListOfProducts from "./components/listofproducts/listofproducts";
import React from "react";
import Posts from "./components/posts/posts";
import Message from "./components/functional/message";
import Counter from "./components/functional/counter";
import PostsFunctional from "./components/functional/posts.functional";
import GetPostById from "./components/getpostbyid/getpostbyid";
class App extends React.Component {
  render() {
    return (
      <div>
        {/* <ListOfProducts /> */}
        {/* <Posts /> */}
        {/* <Message msg="Hello" /> */}
        {/* <Counter /> */}
        {/* <PostsFunctional /> */}
        <GetPostById />
      </div>
    );
  }
}
export default App;
