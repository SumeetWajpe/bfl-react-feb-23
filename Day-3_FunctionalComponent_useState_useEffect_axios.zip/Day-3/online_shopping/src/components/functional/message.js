export default function Message(props) {
  return <h1> {props.msg}</h1>;
}

// const Message = function(){
//     return <h1> Hello !</h1>;
// }

// const Message = () => <h1> Hello !</h1>;
// export default Message;
