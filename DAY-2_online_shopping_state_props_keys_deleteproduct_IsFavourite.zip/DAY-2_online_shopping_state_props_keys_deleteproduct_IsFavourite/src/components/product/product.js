import React from "react";
import Button from "../button/button";

export default class Product extends React.Component {
  state = { currLikes: this.props.productdetails.likes, isFavourite: false };

  ChangeFavourite() {
    this.setState({ isFavourite: !this.state.isFavourite });
  }
  IncrementLikes() {
    console.log("Within Increment Likes ! !");
    // this.props.productdetails.likes++; // props are readonly (for the component)
    // this.state.currLikes++; // state is immutable
    this.setState({ currLikes: this.state.currLikes + 1 });
  }
  render() {
    console.log("Within Render !");
    let ratings = [];
    for (let index = 0; index < this.props.productdetails.rating; index++) {
      ratings.push(
        <i
          className="fa-solid fa-star"
          style={{
            color: "orange",
          }}
          key={index}
        ></i>,
      );
    }
    return (
      <div className="col-sm-6 col-md-4 col-lg-3">
        <div
          className="card rounded-0"
          style={{ boxShadow: "3px 3px 5px gray" }}
        >
          <img
            src={this.props.productdetails.imageUrl}
            alt={this.props.productdetails.title}
            className="card-img-top rounded-0"
            height="200px"
          />
          <div className="card-body p-2">
            <div className="d-flex flex-wrap justify-content-between">
              <h5 className="card-title">{this.props.productdetails.title}</h5>
              <p className="card-text m-0">{ratings}</p>
            </div>

            <p className="card-text "> ₹.{this.props.productdetails.price}</p>

            <div className="d-flex flex-wrap">
              <button
                className="btn btn-primary rounded-0 text-light"
                onClick={() => this.IncrementLikes()}
              >
                <i className="fa-solid fa-thumbs-up"></i>{" "}
                {/* {this.props.productdetails.likes} */}
                {this.state.currLikes}
              </button>

              <button
                className="btn border-dark rounded-0 mx-1 text-dark"
                onClick={() => this.ChangeFavourite()}
              >
                {this.state.isFavourite ? (
                  <i className="fa-solid fa-heart" style={{ color: "red" }}></i>
                ) : (
                  <i className="fa-regular fa-heart"></i>
                )}
              </button>
              <button
                className="btn btn-danger rounded-0 text-light"
                onClick={() =>
                  this.props.DeleteProduct(this.props.productdetails.id)
                }
              >
                <i className="fa-solid fa-trash"></i>
              </button>
            </div>
          </div>
          {/* <button className="btn btn-primary rounded-0 border-0 m-1 font-weight-bold">
            <i className="fa-solid fa-cart-plus"></i> Add to cart
          </button> */}

          <Button classes="btn btn-primary rounded-0 m-1">
            <i className="fa-solid fa-cart-plus"></i> Add to cart
          </Button>
        </div>
      </div>
    );
  }
}

// import React from "react";
// import { ProductModel } from "../../models/product.model";
// import { Button } from "../button/button";
// import { Rating } from "../rating/rating";

// // interface ProductProps {
// //   productdetails: ProductModel;
// // }

// type ProductProps = {
//   productdetails: ProductModel;
// };

// class Product extends React.Component<ProductProps> {
//   state = { currLikes: this.props.productdetails.likes, isFavourite: false };
//   IncrementLikes() {
//     //this.props.productdetails.likes += 1; // props are readonly
//     // this.state.currLikes += 1; // state is immutable
//     console.log(this);
//     this.setState({ currLikes: this.state.currLikes + 1 });
//   }
//   ToggleFavourite() {
//     // this.state.isFavourite = !this.state.isFavourite;// will not work as state is mutated
//     this.setState({ isFavourite: !this.state.isFavourite });
//   }
//   render(): React.ReactNode {
//     return (
//       <div className="col-sm-6 col-md-4 col-lg-3">
//         <div
//           className="card rounded-0"
//           style={{ boxShadow: "3px 3px 5px gray" }}
//         >
//           <img
//             src={this.props.productdetails.imageUrl}
//             alt={this.props.productdetails.title}
//             className="card-img-top rounded-0"
//             height="200px"
//           />
//           <div className="card-body p-2">
//             <div className="d-flex flex-wrap justify-content-between">
//               <h5 className="card-title">{this.props.productdetails.title}</h5>
//               <p className="card-text m-0">
//                 <Rating
//                   noofstars={this.props.productdetails.rating}
//                   color="orange"
//                 />
//               </p>
//             </div>

//             <p className="card-text "> ₹.{this.props.productdetails.price}</p>

//             <div className="d-flex flex-wrap">
//               <Button
//                 classes="btn btn-primary rounded-0 text-light"
//                 ClickHandler={() => this.IncrementLikes()}
//               >
//                 <i className="fa-solid fa-thumbs-up"></i> {this.state.currLikes}
//               </Button>

//               <Button
//                 classes="btn btn-primary btn-outline rounded-0 mx-1 text-dark"
//                 ClickHandler={() => this.ToggleFavourite()}
//               >
//                 {this.state.isFavourite ? (
//                   <i className="fa-solid fa-heart"></i>
//                 ) : (
//                   <i className="fa-regular fa-heart"></i>
//                 )}
//               </Button>
//               <Button classes="btn btn-danger rounded-0 text-light">
//                 <i className="fa-solid fa-trash"></i>
//               </Button>
//             </div>

//             {/* <Button bgColor="white" textColor="black" text="Add to favourite" /> */}
//           </div>
//           <Button classes="btn btn-primary btn-purple rounded-0 border-0 m-1 font-weight-bold">
//             <i className="fa-solid fa-cart-plus"></i> Add to cart
//           </Button>
//         </div>
//       </div>
//     );
//   }
// }

// export default Product;
