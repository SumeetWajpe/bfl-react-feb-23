import logo from "./logo.svg";
import "./App.css";
import ListOfProducts from "./components/listofproducts/listofproducts";
import React from "react";
class App extends React.Component {
  render() {
    return (
      <div>
        <ListOfProducts />
      </div>
    );
  }
}
export default App;
