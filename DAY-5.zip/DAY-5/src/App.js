import logo from "./logo.svg";
import "./App.css";
import ListOfProducts from "./components/listofproducts/listofproducts";
import React from "react";
import Posts from "./components/posts/posts";
import Message from "./components/functional/message";
import Counter from "./components/functional/counter";
import PostsFunctional from "./components/functional/posts.functional";
import GetPostById from "./components/getpostbyid/getpostbyid";
import { BrowserRouter, Link, Route, Routes } from "react-router-dom";
import NewProduct from "./components/newproduct/newproduct";
import Navbar from "./components/navbar/navbar";
import PostDetails from "./components/postdetails/postdetails";
import GrandParent from "./components/contextapi/context";
class App extends React.Component {
  render() {
    return (
      <BrowserRouter>
        <Navbar />
        <Routes>
          <Route path="/" element={<ListOfProducts />}></Route>
          <Route path="/newproduct" element={<NewProduct />}></Route>
          <Route path="/posts" element={<PostsFunctional />}></Route>
          <Route path="/postdetails/:id" element={<PostDetails />}></Route>
          <Route path="/contextapi" element={<GrandParent />}></Route>
          <Route
            path="*"
            element={
              <img src="https://www.online-tech-tips.com/wp-content/uploads/2022/03/image-41.jpeg" />
            }
          ></Route>
        </Routes>
      </BrowserRouter>
    );
  }
}
export default App;
