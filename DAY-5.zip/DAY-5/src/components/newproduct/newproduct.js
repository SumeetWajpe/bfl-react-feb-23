import React, { useState } from "react";
import { ProductModel } from "../../model/product.model";
import { useForm } from "react-hook-form";
import { yupResolver } from "@hookform/resolvers/yup";
import schema from "../../schema/newproduct.schema";
export default function NewProduct(props) {
  const {
    register,
    handleSubmit,
    formState: { errors },
    reset,
  } = useForm({
    resolver: yupResolver(schema),
  });
  return (
    <div className="row justify-content-center m-2 ">
      <div className="col-md-6 border border-2 rounded-2 m-2">
        <h2>Add New Product</h2>
        <form
          className="row g-1 align-items-center text-center"
          onSubmit={handleSubmit(data => {
            props.AddNewProduct(data);
            reset();
          })}
        >
          <div className="col-md-4 ">
            <label> Id :</label>
          </div>
          <div className="col-md-8">
            <input type="text" className="form-control" {...register("id")} />
            {errors.id && (
              <div className="d-flex align-items-baseline g-1">
                <i
                  className="fa-solid fa-circle-exclamation m-2"
                  style={{ color: "red" }}
                ></i>
                <p className="text-danger">{errors.id.message}</p>
              </div>
            )}
          </div>
          <div className="col-md-4">
            <label> Title :</label>
          </div>

          <div className="col-md-8">
            <input
              type="text"
              className="form-control"
              {...register("title")}
            />
            {errors.title && (
              <div className="d-flex align-items-baseline g-1">
                <i
                  className="fa-solid fa-circle-exclamation m-2"
                  style={{ color: "red" }}
                ></i>
                <p className="text-danger">{errors.title.message}</p>
              </div>
            )}
          </div>
          <div className="col-md-4">
            <label> Price :</label>
          </div>

          <div className="col-md-8">
            <input
              type="text"
              className="form-control"
              {...register("price")}
            />
          </div>
          <div className="col-md-4">
            <label> Rating :</label>
          </div>

          <div className="col-md-8">
            <input
              type="text"
              className="form-control"
              {...register("rating")}
            />
          </div>
          <div className="col-md-4">
            <label> Likes :</label>
          </div>

          <div className="col-md-8">
            <input
              type="text"
              className="form-control"
              {...register("likes")}
            />
          </div>
          <div className="col-md-4">
            <label> Image (url) :</label>
          </div>

          <div className="col-md-8">
            <input
              type="text"
              className="form-control"
              {...register("imageUrl")}
            />
          </div>
          <div className="row justify-content-center">
            <div className="col-md-8 m-2">
              <button className="btn btn-success">Add New Product</button>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
}
