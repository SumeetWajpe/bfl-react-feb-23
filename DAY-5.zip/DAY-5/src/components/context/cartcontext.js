import React, { useContext, useState } from "react";

export const CartContext = React.createContext({ cartItems: [] });

export default function CartContextProvider(props) {
  let [currCartItems, setCurrCartItems] = useState([]);

  function AddNewItemToCart(newProduct) {
    setCurrCartItems([...currCartItems, newProduct]);
  }
  return (
    <CartContext.Provider
      value={{ cartItems: currCartItems, AddNewItemToCart }}
    >
      {props.children}
    </CartContext.Provider>
  );
}
