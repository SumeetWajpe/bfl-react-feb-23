import React, { Component } from "react";
import axios from "axios";
export default class Posts extends Component {
  state = { posts: [] };
  componentDidMount() {
    axios
      .get("https://jsonplaceholder.typicode.com/posts")
      .then(response => this.setState({ posts: response.data }));
  }
  render() {
    let contentToBeRendered = "";
    if (this.state.posts.length) {
      contentToBeRendered = (
        <ul className="list-group">
          {this.state.posts.map(post => (
            <li className="list-group-item" key={post.id}>
              {post.title}
            </li>
          ))}
        </ul>
      );
    } else {
      contentToBeRendered = (
        <img
          src="https://miro.medium.com/max/1400/1*Gvgic29bgoiGVLmI6AVbUg.gif"
          alt="Loading"
        />
      );
    }
    return (
      <div>
        <header>
          <h1>Posts</h1>
        </header>
        <main>{contentToBeRendered}</main>
      </div>
    );
  }
}
