import React, { useState, useEffect } from "react";
import axios from "axios";
export default function GetPostById() {
  let [postId, setPostId] = useState(1);
  let [post, setPost] = useState({});
  useEffect(() => {
    axios
      .get(`https://jsonplaceholder.typicode.com/posts/${postId}`)
      .then(response => setPost(response.data));
  }, [postId]);
  return (
    <div>
      <label>Enter Post Id : </label>{" "}
      <input
        type="number"
        value={postId}
        onChange={e => setPostId(e.target.value)}
      />
      <h2>{post.title}</h2>
    </div>
  );
}
