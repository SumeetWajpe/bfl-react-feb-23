import axios from "axios";
import React, { useEffect, useState } from "react";
import { useParams } from "react-router-dom";

export default function PostDetails() {
  let { id } = useParams();
  let [post, setPost] = useState({});
  useEffect(() => {
    axios
      .get(`https://jsonplaceholder.typicode.com/posts/${id}`)
      .then(response => setPost(response.data));
  }, []);
  return (
    <div>
      <section>
        <div className="card text-center">
          <div className="card-header">Post Details for post id - {id}</div>
          <div className="card-body">
            <h5 className="card-title">{post.title}</h5>
            <p className="card-text">{post.body}</p>
          </div>
          <div className="card-footer text-muted">User Id - {post.userId}</div>
        </div>
      </section>
    </div>
  );
}
