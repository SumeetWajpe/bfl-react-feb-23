import React, { useContext, useState } from "react";

let CounterContext = React.createContext({});

export function CounterProvider(props) {
  let [count, setCount] = useState(200);

  function ChangeCount() {
    setCount(++count);
  }
  return (
    <div>
      <CounterContext.Provider value={{ count, ChangeCount }}>
        {props.children}
      </CounterContext.Provider>
    </div>
  );
}

export default function GrandParent() {
  return (
    <CounterProvider>
      <Parent />
    </CounterProvider>
  );
}

export function Parent() {
  return (
    <div>
      <Child />
      <Leaf />
    </div>
  );
}

// export function Child() {
//   return (
//     <CounterContext.Consumer>
//       {value => <p> Count : {value}</p>}
//     </CounterContext.Consumer>
//   );
// }

// OR

export function Child() {
  let ctx = useContext(CounterContext);
  return (
    <div>
      <p>Count : {ctx.count}</p>
      <button
        className="btn btn-primary btn-sm"
        onClick={() => ctx.ChangeCount()}
      >
        ++
      </button>
    </div>
  );
}

export function Leaf() {
  let ctx = useContext(CounterContext);
  return (
    <div>
      <h2>Count : {ctx.count}</h2>
      <button
        className="btn btn-success btn-sm"
        onClick={() => ctx.ChangeCount()}
      >
        ++
      </button>
    </div>
  );
}
