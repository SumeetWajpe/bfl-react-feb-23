import React from "react";
import logo from "./logo.svg";
import "./App.css";
import Message from "./components/message/message";

class App extends React.Component {
  messages = [
    {
      msg: "Hey",
      from: "John",
      to: "Wick",
      url: "https://www.shutterstock.com/image-vector/vector-illustartion-speech-bubble-hey-260nw-1821011048.jpg",
    },
    {
      msg: "Hi",
      from: "John",
      to: "Carter",
      url: "https://www.shutterstock.com/image-vector/vector-illustartion-speech-bubble-hey-260nw-1821011048.jpg",
    },

    {
      msg: "Hola",
      from: "Jason",
      to: "Bourne",
      url: "https://www.shutterstock.com/image-vector/vector-illustartion-speech-bubble-hey-260nw-1821011048.jpg",
    },
    {
      msg: "Bye",
      from: "James",
      to: "Bond",
      url: "https://www.shutterstock.com/image-vector/vector-illustartion-speech-bubble-hey-260nw-1821011048.jpg",
    },
  ];
  render() {
    return (
      <div className="row">
        {this.messages.map(m => (
          <Message msgDetails={m} />
        ))}
      </div>
    );
  }
}

export default App;
