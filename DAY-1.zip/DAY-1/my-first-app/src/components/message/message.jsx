import React from "react";
import "./message.css";
class Message extends React.Component {
  render() {
    return (
      <div className="col-md-4">
        <div class="card" style={{ width: "18rem" }}>
          <img
            src={this.props.msgDetails.url}
            alt={this.props.msgDetails.msg}
            className="card-img-top"
          />
          <div className="card-body">
            <h5 className="card-title">{this.props.msgDetails.msg}</h5>
            <p className="card-text">
              <i className="fa-solid fa-star"></i>
              <i className="fa-solid fa-star"></i>
              <i className="fa-solid fa-star"></i>
              <i className="fa-solid fa-star"></i>
            </p>
            <p className="card-text">
              <strong>From : {this.props.msgDetails.from}</strong>
            </p>
            <p className="card-title">
              <strong>To : {this.props.msgDetails.to}</strong>
            </p>
          </div>
        </div>
      </div>
    );
  }
}

export default Message;
