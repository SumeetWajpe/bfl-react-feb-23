import "./App.css";
import React, { Suspense } from "react";
import { BrowserRouter, Link, Route, Routes } from "react-router-dom";

// import PostsFunctional from "./components/functional/posts.functional";
import NewProduct from "./components/newproduct/newproduct";
import Navbar from "./components/navbar/navbar";
import PostDetails from "./components/postdetails/postdetails";
import GrandParent from "./components/contextapi/context";
import ListOfProducts from "./components/listofproducts/listofproducts";
const PostsFunctional = React.lazy(() =>
  import("./components/functional/posts.functional"),
);

class App extends React.Component {
  render() {
    return (
      <BrowserRouter>
        <Navbar />
        <Routes>
          <Route path="/" element={<ListOfProducts />}></Route>
          <Route path="/newproduct" element={<NewProduct />}></Route>
          <Route
            path="/posts"
            element={
              <Suspense fallback={<div>Loading...</div>}>
                <PostsFunctional />
              </Suspense>
            }
          ></Route>
          <Route path="/postdetails/:id" element={<PostDetails />}></Route>
          <Route path="/contextapi" element={<GrandParent />}></Route>
          <Route
            path="*"
            element={
              <img src="https://www.online-tech-tips.com/wp-content/uploads/2022/03/image-41.jpeg" />
            }
          ></Route>
        </Routes>
      </BrowserRouter>
    );
  }
}
export default App;
