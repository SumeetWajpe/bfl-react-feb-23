import React, { useContext } from "react";
import { CartContext } from "../context/cartcontext";

export default function CartBadge() {
  let cartCtx = useContext(CartContext);
  return (
    <div className="d-flex align-items-center">
      <div className="fs-5">
        <i className="fa-solid fa-cart-shopping" style={{ color: "white" }}></i>
      </div>

      <span className="badge badge-pill bg-primary mx-1">
        {cartCtx.cartItems.length}
      </span>
    </div>
  );
}
