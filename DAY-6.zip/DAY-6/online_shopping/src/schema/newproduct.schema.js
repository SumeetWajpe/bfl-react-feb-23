import * as yup from "yup";

const schema = yup.object().shape({
  id: yup
    .number()

    .required("Product Id is required !")
    .typeError("Product Id shuould be a number"),
  //.transform(value => (isNaN(value) ? undefined : value))
  //.nullable(),
  title: yup.string().required("Product Title is required !").min(8).max(20),
});
export default schema;
